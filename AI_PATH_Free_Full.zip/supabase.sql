-- Run in Supabase SQL editor. Only authenticated owners can read/write their workspace.
create table if not exists public.aipath_workspaces (
 owner uuid primary key references auth.users(id) on delete cascade,
 payload jsonb not null default '{}'::jsonb,
 updated_at timestamptz not null default now()
);
alter table public.aipath_workspaces enable row level security;
create policy "aipath owner select" on public.aipath_workspaces for select to authenticated using (auth.uid() = owner);
create policy "aipath owner insert" on public.aipath_workspaces for insert to authenticated with check (auth.uid() = owner);
create policy "aipath owner update" on public.aipath_workspaces for update to authenticated using (auth.uid() = owner) with check (auth.uid() = owner);
create policy "aipath owner delete" on public.aipath_workspaces for delete to authenticated using (auth.uid() = owner);
-- Document text is part of owner-only JSON. No public storage bucket is created.
