import { timingSafeEqual } from 'node:crypto';
const providers={openrouter:['https://openrouter.ai/api/v1','OPENROUTER_API_KEY']};
const freeId=id=>typeof id==='string'&&(id==='openrouter/free'||/^[a-zA-Z0-9_.-]+\/[a-zA-Z0-9_.-]+:free$/.test(id));
const zero=v=>(typeof v==='number'||(typeof v==='string'&&v.trim()!==''))&&Number(v)===0;
const freeModel=m=>m&&freeId(m.id)&&m.pricing&&zero(m.pricing.prompt)&&zero(m.pricing.completion)&&Object.values(m.pricing).every(zero);
const reply=(statusCode,data)=>({statusCode,headers:{'Content-Type':'application/json','Cache-Control':'no-store'},body:JSON.stringify(data)});
const same=(a,b)=>{const x=Buffer.from(String(a||'')),y=Buffer.from(String(b||''));return x.length===y.length&&timingSafeEqual(x,y)};
async function request(url,opts={}){const r=await fetch(url,{...opts,signal:AbortSignal.timeout(24000)});if(!r.ok){const e=new Error('Upstream returned HTTP '+r.status);e.status=r.status;throw e;}return r.json()}
const validString=(s,n)=>typeof s==='string'&&s.length>0&&s.length<=n;
export async function handler(event){
 if(event.httpMethod!=='POST')return reply(405,{error:'POST required'});
 if(!process.env.AIPATH_ACCESS_CODE)return reply(503,{error:'Owner must configure AIPATH_ACCESS_CODE on Netlify.'});
 if(!same(event.headers?.['x-aipath-code']||event.headers?.['X-Aipath-Code'],process.env.AIPATH_ACCESS_CODE))return reply(401,{error:'Incorrect or missing workspace access code.'});
 if(event.isBase64Encoded||!event.body||event.body.length>180000)return reply(413,{error:'Request too large or missing.'});
 let b;try{b=JSON.parse(event.body)}catch{return reply(400,{error:'Invalid JSON'});}
 if(!b||typeof b!=='object'||Array.isArray(b))return reply(400,{error:'Invalid request object'});
 try{
 if(b.action==='status')return reply(200,{providers:Object.keys(providers).filter(p=>!!process.env[providers[p][1]]),search:false,freeOnly:true});
 if(b.action==='search')return reply(403,{error:'Metered search API disabled in Free Edition. Use Research links.'});
 if(b.action==='mail'){
  if(!validString(b.token,8000))return reply(400,{error:'A read-only OAuth access token is required.'});
  const h={Authorization:'Bearer '+b.token};let results=[];
  if(b.service==='gmail'){
   const d=await request('https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=15&q='+encodeURIComponent(String(b.query||'').slice(0,400)),{headers:h});
   results=await Promise.all((d.messages||[]).slice(0,15).map(async m=>{const x=await request('https://gmail.googleapis.com/gmail/v1/users/me/messages/'+encodeURIComponent(m.id)+'?format=metadata&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=Date',{headers:h});const hd=Object.fromEntries((x.payload?.headers||[]).map(a=>[a.name.toLowerCase(),a.value]));return {title:hd.subject||'(No subject)',description:[hd.from,hd.date,x.snippet].filter(Boolean).join(' — '),url:'https://mail.google.com/mail/u/0/#all/'+encodeURIComponent(m.id)}}));
  }else if(b.service==='microsoft'){
   const q=new URLSearchParams({'$top':'15','$select':'subject,from,receivedDateTime,bodyPreview,webLink'});if(b.query)q.set('$search','"'+String(b.query).replace(/["\\]/g,'').slice(0,400)+'"');
   const d=await request('https://graph.microsoft.com/v1.0/me/messages?'+q,{headers:h});results=(d.value||[]).map(x=>({title:x.subject||'(No subject)',description:[x.from?.emailAddress?.address,x.receivedDateTime,x.bodyPreview].filter(Boolean).join(' — '),url:x.webLink}));
  }else return reply(400,{error:'Unsupported email service'});
  return reply(200,{results});
 }
 if(!Object.hasOwn(providers,b.provider))return reply(400,{error:'Unknown provider'});
 const [base,keyName]=providers[b.provider],key=process.env[keyName];
 const headers=key?{Authorization:'Bearer '+key}:{};
 if(b.action==='models'){
  const d=await request(base+'/models',{headers});return reply(200,{models:(Array.isArray(d.data)?d.data:[]).filter(freeModel).map(m=>({id:m.id,name:m.name||m.id,context:m.context_length??null,pricing:m.pricing,architecture:m.architecture??null}))});
 }
 if(b.action!=='chat')return reply(400,{error:'Unknown action'});
 if(!key)return reply(503,{error:keyName+' not configured.'});
 if(!validString(b.model,250)||!Array.isArray(b.messages)||b.messages.length<1||b.messages.length>42||b.messages.some(m=>!m||!['system','user','assistant'].includes(m.role)||!validString(m.content,60000))||!b.messages.some(m=>m.role==='user'))return reply(400,{error:'Invalid model or conversation.'});
 if(!freeId(b.model))return reply(403,{error:'Paid or unrecognised model blocked. Choose openrouter/free or a verified :free model.'});
 if(b.model!=='openrouter/free'){
  const catalog=await request(base+'/models',{headers});
  if(!Array.isArray(catalog.data)||!catalog.data.some(m=>m.id===b.model&&freeModel(m)))return reply(403,{error:'Model no longer listed with zero pricing. Refresh the catalog or choose openrouter/free.'});
 }
 const d=await request(base+'/chat/completions',{method:'POST',headers:{'Content-Type':'application/json',...headers},body:JSON.stringify({model:b.model,messages:b.messages.map(({role,content})=>({role,content})),max_tokens:2048,stream:false,provider:{max_price:{prompt:0,completion:0}}})});
 const choice=d.choices?.[0]?.message; if(typeof choice?.content!=='string'||!choice.content)return reply(502,{error:'Provider returned no text response.'});
 return reply(200,{text:choice.content,usage:d.usage,model:d.model||b.model});
 }catch(e){return reply(e.status===429?429:502,{error:e.status?'Upstream HTTP '+e.status+' — check credentials, model, quota or provider availability.': 'Upstream request failed or timed out.'});}
}
