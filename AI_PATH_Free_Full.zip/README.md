# AI PATH v1.1 — FREE EDITION

## Get online without a paid subscription
1. Create a free OpenRouter account at https://openrouter.ai/ and create an API key at https://openrouter.ai/keys. Do not buy credits or enable automatic payments. The free account is the additional financial protection; this application cannot inspect your account billing settings.
2. Extract AI_PATH_Free_Full.zip. Upload its contents (not the enclosing ZIP) into a private GitHub repository. Create a Netlify Free account and import the repository as a project. Netlify reads netlify.toml: public is the publish directory and netlify/functions is the function directory. No build command or npm installation required.
3. In Netlify project configuration, add function-scoped environment variables OPENROUTER_API_KEY (your secret key) and AIPATH_ACCESS_CODE (your own strong random secret, 24+ characters). Redeploy. Never put secrets in HTML or GitHub.
4. Visit the deployed HTTPS site, open Infrastructure, enter your access code and Connect / test. Go to AI studio and select openrouter/free (default), then send a harmless test message. Status only verifies configuration, not live inference. In Model exchange you can refresh the live list of free variants. If quota is exhausted the app reports an error; it never switches to paid inference.
5. The HTML file and Netlify Drop ZIP are local/static previews only. They do not deploy the server gateway. CRM, text knowledge vault, resource directory and public research links work without a backend.

## Free-only enforcement
The server permits only OpenRouter and the documented openrouter/free router or explicitly named :free variants. Individual variants require a fresh catalog check with zero prompt/completion pricing and all supplied pricing fields zero. The gateway submits a zero prompt/completion price ceiling, removes untrusted extra request fields, and does not send paid tools or fallback model lists. Other AI providers and the Brave Search API are disabled even if their keys exist. This is a code restriction, not a billing certification. Provider terms, pricing and availability can change. Keep your OpenRouter account unfunded and use only free hosting plans.

OpenRouter currently documents 50 requests/day and 20/minute for :free variants on unfunded accounts; quotas can change and failures count. Netlify's credit-based Free plan has a 300-credit monthly hard limit. Do not upgrade or purchase credits. If limits are reached, stop or wait until reset. No guarantee of unlimited access.

## Other modules
CRM, text evidence vault, chat history and exports are local-first. Data is not encrypted in localStorage. Research uses ordinary public search-engine links, not automatic retrieval. The directory preserves 198 curated links, including platforms with paid offerings; links are not integrations or individually verified free services. Do not purchase anything through linked sites. Specialist agents are prompt profiles, not autonomous workers.

Optional cloud snapshots: use Supabase Free only. Run supabase.sql in the SQL editor once; configure project URL, publishable/anon key and credentials under Infrastructure. Never use a service-role key. Manual push/pull replaces the destination after confirmation; row-level policies restrict owner access. No binary document storage, PDF extraction or vector memory. Free quotas and provider terms apply.

Email previews require your own authorised, short-lived Gmail gmail.readonly or Microsoft Graph Mail.Read delegated OAuth token. The app retrieves up to 15 previews and does not implement automatic consent, attachments or full-message retrieval. External account and developer access requirements apply.

Security: owner-operated starter, not production multi-user authentication. Use a strong unique access code and keep it private. Prompts go to OpenRouter and selected model providers; free providers may retain or train on data under their terms. Do not submit confidential legal, medical or banking records without reviewing privacy policies. No live deployment, real API billing test or security certification performed.

## Sources checked 25 November 2026
- https://openrouter.ai/collections/free-models
- https://openrouter.ai/openrouter/free
- https://openrouter.ai/docs/api/api-reference/models/get-models
- https://openrouter.ai/blog/tutorials/how-to-get-the-lowest-cost-llm-inference-on-openrouter/
- https://docs.netlify.com/manage/accounts-and-billing/billing/billing-for-credit-based-plans/credit-based-pricing-plans/

See TEST-REPORT.md and test-gateway.mjs for local test coverage.
