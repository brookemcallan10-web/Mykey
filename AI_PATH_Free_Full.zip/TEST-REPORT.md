# AI PATH Free Edition — test report

Local Node.js gateway tests. Upstream HTTP calls mocked. Browser script and gateway syntax checked with node --check. No live API, billing, hosting or UI interaction tests performed for this revision.

PASS missing code configuration
PASS incorrect access code
PASS GET denied
PASS malformed JSON
PASS null body
PASS oversize body
PASS only free provider exposed
PASS paid provider denied
PASS metered search blocked despite key
PASS paid model denied
PASS auto router denied
PASS suffix injection denied
PASS catalog filtered
PASS nonzero request fee denied
PASS missing price denied
PASS null price denied
PASS nonexistent free model denied
PASS free model success mock
PASS free router and injection stripping
PASS invalid messages
PASS missing mail token
PASS quota failure does not fall back
22 tests passed; all upstream calls mocked.
